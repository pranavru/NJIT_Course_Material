for rows = 1:255
    for cols = 1:255
        if lena(rows, cols) > 200
           lena(rows, cols) = 1;
        elseif lena(rows, cols) < 100
            lena(rows, cols) = 1;
        else
            lena(rows, cols) = 0;
        end
    end
end
