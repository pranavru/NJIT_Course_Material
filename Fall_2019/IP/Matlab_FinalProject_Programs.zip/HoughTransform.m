%Hough Transform
function [a, M] = HoughTransform(theta, a) 
    matrix_size = 8;
%     a = zeros(matrix_size);
%     for i = matrix_size: 1 
%         for j = 1 : matrix_size
%             if(i == j) 
%                 a(i, j) = 1;
%             end
%         end
%     end
     disp(a);

    M = zeros(8);

    
    for j = 1 : matrix_size
        for k = 1: matrix_size
           if  a(j, k) > 0
               d = j .* cos(theta) + k .* sin(theta);
               disp(j)
               disp(theta)
               disp( a(j, k) .* cos(theta))
               disp( a(j, k) .* sin(theta))
               M(j, k) = round(d);
           end
        end
    end
    
    disp(M);
end
