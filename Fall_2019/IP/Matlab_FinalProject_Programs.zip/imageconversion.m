function [imageConverted] = imageconversion(img) 
    resize = 768;
    imageConverted = imresize(img, [resize, resize]);
    imageConverted = rgb2gray(imageConverted);
    imageConverted = imgaussfilt(imageConverted, 1);
    imageConverted = medfilt2(imageConverted);
%     Detecting the edges
    imageConverted = edgeDetectionofImage(imageConverted);
    imageConverted = uint8(imageConverted);
end

function [edgedImg] = edgeDetectionofImage(img)
    edgedImg = edge( img, "Sobel");
end