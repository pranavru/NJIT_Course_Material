import java.util.*;
import java.io.*;


public class InstructionCycle
{
	private final int SIZE = 16;
	private String[][] mem;
	private String fileName;
	private Scanner fin ;
	private int pcreg;
	private int basereg;
	private int lines;
	private int acreg;
	private int mareg;
	private int mbreg;
	private String instreg;
	private int [] val;
	private static int index;
	
	
	
	public InstructionCycle(String f, int p, int b, int l)
	{
		mem = new String[SIZE][SIZE];			//initialized to null
		fileName = f;
		pcreg = p;
		basereg = b;
		lines = l;
		fin = null;
		acreg = 0;
		mareg = 0;
		mbreg = 0;
		val = new int [SIZE];
		index = 0;
	}
	
	
	public void openFile(String a, int b, int c, int d)
	{
		try
		{
			fin = new Scanner(new FileInputStream(fileName));
		}
		catch(FileNotFoundException e)
		{
			System.out.println("problem opening file");
			System.exit(1);
		}
		System.out.println("memory chip 16 X 16 args--> " + a + 
											 " " + b + " " + c + " " + d + "\n");
	}
	
	
	public void readFile()
	{
		int index;
		String code;
		int hex; 
		while(fin.hasNextLine())
		{
			index =fin.nextInt();
			code = fin.next();			//ignores leading whitespace
			fin.nextLine();					//removes the '\n' char
			int row = index / SIZE;
			int col = index % SIZE;
			mem[row][col] = code;		//load memory, 16 bit binary string
		}
	}
	
	
	public void fetch()
	{
		for(int i = 0; i < lines; i++)
		{
			int start = basereg + pcreg;
			parse(start);						//starting index line of code
			pcreg++;								//advance program counter	
		}
	}
	
	
	public void parse(int codeLine)
	{
		int row = codeLine / SIZE;
		int col = codeLine % SIZE;
		execute(row, col);
	} 
	
	
	public void execute(int r, int c)
	{
		instreg = mem[r][c];
		
		
		int opcode = Integer.parseInt(mem[r][c], 2) / 4096;	//opcode
		mareg = Integer.parseInt(mem[r][c], 2) % 4096;			//address
		
		r = mareg / SIZE;							//new row index for output
		c = mareg % SIZE;							//new col index for output
				
		switch(opcode)
		{
			case 1:											//load acreg from mem
				acreg = Integer.parseInt(mem[r][c], 2);
				break;
			case 2:											//move mbreg to acreg
				acreg = mbreg;
				mbreg = 0;
				break;
			case 3:											//move acreg to mbreg
				mbreg = acreg;
				acreg = 0;
				break;
			case 4:											//add acreg from mbreg
				acreg += mbreg;
				break;				
			case 5:											//subtract acreg from mbreg
				acreg -= mbreg;
				break;
			case 6:											//mult acreg from mbreg
				acreg *= mbreg;
				break;
			case 7:											//add acreg from mem
				acreg += Integer.parseInt(mem[r][c], 2);
				break;	
			case 8:											//subtract acreg from mem
				acreg -= Integer.parseInt(mem[r][c], 2);
				break;
			case 9:											//mult acreg from mem
				acreg *= Integer.parseInt(mem[r][c], 2);
				break;				
			case 10:										//inc acreg
				acreg++;
				break;
			case 11:										//dec acreg
				acreg--;
				break;
			case 12:										//inc mbreg
				mbreg++;
				break;
			case 13:										//load mbreg from mem
				mbreg = Integer.parseInt(mem[r][c], 2);
				break;
			case 14:										//stor mbreg to mem
				mem[r][c] = Integer.toString(mbreg, 2);
				val[index] = mbreg;
				index++;
				mbreg = 0;
				break;
			case 15:										//stor acreg to mem
				mem[r][c] = Integer.toString(acreg, 2);
				val[index] = acreg;
				index++;
				acreg = 0;
				break;
			default:			
		}			
	} 
			 
	
	private void delay()
	{
		for (int i = 0; i < 10000; i++)
			for (int j = 0; j < 10000; j++);
	}
	
	
	public void display()
	{
		System.out.print("col->");
		for (int i = 0; i < SIZE; i++)
			System.out.print("\t" + " " + i);
			
		System.out.println("\n");
		for (int r = 0; r < SIZE; r++)
		{
			System.out.print("row " + r);

			for (int c = 0; c < SIZE; c++)
			{
				if(mem[r][c] != null)
				{
					int num = Integer.parseInt(mem[r][c], 2);
					mem[r][c] = Integer.toString(num, SIZE);
				}
				else
					mem[r][c] = "****";
				System.out.print("\t" + mem[r][c]);
				delay();
			}
			System.out.println("\n");
		}   
	}
	
	
	public void showValues()
	{
		for(int i = 0; i < index; i++)
		{
			System.out.println("VAL " + (i + 1) + "  " + val[i]);
		}
		System.out.println();
		System.out.println("Base		PC		IR			MAR		MBR		AC");
		System.out.println(basereg + "\t\t" + pcreg + "\t\t" + instreg 
							+	"\t" + mareg + "\t\t" + mbreg + "\t\t" + acreg);
	} 
}