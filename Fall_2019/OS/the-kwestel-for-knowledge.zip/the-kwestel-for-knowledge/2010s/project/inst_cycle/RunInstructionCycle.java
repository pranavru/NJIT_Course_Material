public class RunInstructionCycle
{
	public static void main(String [] args)
	{
		if (args.length != 4)
			System.exit(1);
		else
		{
			String file = args[0];
			int pc = Integer.parseInt(args[1]);
			int base = Integer.parseInt(args[2]);
 			int lines = Integer.parseInt(args[3]);
			InstructionCycle ic;  
			ic = new InstructionCycle(file, pc,	base, lines);
	 		ic.openFile(file, pc, base, lines);
	 		ic.readFile();
			ic.fetch();
	 		ic.display();
			ic.showValues();
		}	   
	}
}