public class Test
{
	public static void main(String [] args)
	{
		String s = "1111111111111111";
		int a = Integer.parseInt(s, 2);
		System.out.println(a);						//65535
		String t = s.substring(0, 4);
		int b =  Integer.parseInt(t, 2);
		System.out.println(b);						//15
		String v = Integer.toString(2766, 16);
		System.out.println(v);	
	}
}