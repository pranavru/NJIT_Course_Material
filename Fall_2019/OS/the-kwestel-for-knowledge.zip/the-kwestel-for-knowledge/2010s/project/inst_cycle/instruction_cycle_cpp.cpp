/*command line parameters: <exe>  infile.txt  100  1501  50  */

#include<iostream>
#include<fstream>
#include<cstdlib>
#include<iomanip>
using namespace std;

void openfile(char filename[], ifstream &infile);
void readfile(ifstream &infile);
void fetch(unsigned short int begin, unsigned short int total);
void execute(unsigned short int sequence);
void display();
void request();

const unsigned short int MEM = 4096;

                                       //global data - memory & registers
unsigned short int memory[MEM];
unsigned short int bs_reg = 0, pc_reg = 0, ac_reg = 0;
unsigned short int ir_reg = 0, ma_reg = 0, mb_reg = 0;

int main(int argc, char* argv[])
{
	if (argc != 5)
   {
   	cout << "syntax: xxx0000	filename num1 num2 num3" << endl;
      exit(0);
   }
   display();
   unsigned short int lines, start;
   ifstream fin;
   openfile(argv[1], fin); 				//call function to open file
   pc_reg = atoi(argv[2]);
   bs_reg = atoi(argv[3]);
   lines = atoi(argv[4]);
   start = pc_reg + bs_reg;
   readfile(fin);								//call function to read file & load 'memory'
   fin.close();
   fetch(start, lines);
   display();
   request();
   return 0;
}

void openfile(char filename[], ifstream &infile)
{
	infile.open(filename);              //open file
   if (infile.fail())                  //test for proper open
	{
		cout << "file could not be opened \n";
		exit(-1);
	}
   return;
}

void readfile(ifstream &infile)
{
	unsigned short int index, value;

   while (infile >> index >> value)				//read file and load 'memory'
   {
   	memory[index] = value;
   }
}

void fetch(unsigned short int begin, unsigned short int total)
{
   unsigned short int code;
	for (int i = 0; i < total; i++)
   {
   	code = memory[begin];
      execute(code);
      begin++;
      pc_reg = begin - bs_reg;
   }
   return;
}

void execute(unsigned short int sequence)
{
   unsigned short int opcode, address;
   ir_reg = sequence;
   ma_reg = address = sequence % MEM;
   opcode = sequence / MEM;

   switch (opcode)
   {
   	case (0):
      	mb_reg = memory[address];		 	//load mbr from memory
         break;
      case (1):
      	ac_reg = memory[address];			//load ac from memory
         break;
      case (2):
      	ac_reg = mb_reg;					  	//move mbr to ac
         break;
      case (3):
      	mb_reg = ac_reg;						//move ac to mbr
         break;
      case (4):
      	ac_reg += mb_reg;						//add ac from mbr
         break;
      case (5):
      	ac_reg -= mb_reg;						//sub ac from mbr
         break;
      case (6):
      	ac_reg *= mb_reg;						//mult ac from mbr
         break;
      case (7):
      	ac_reg += memory[address];			//add ac from mem
         break;
      case (8):
      	ac_reg -= memory[address];			//sub ac from mem
         break;
      case (9):
      	ac_reg *= memory[address];			//mult ac from mem
         break;
      case (10):
      	ac_reg++;								//inc ac
         break;
     	case (11):
      	ac_reg--;								//dec ac
         break;
		case (12):
      	mb_reg++;								//inc mbr
         break;
      case (13):
      	mb_reg--;								//dec mbr
         break;
      case (14):
      	memory[address] = mb_reg;			//stor mbr to memory
         break;
      case (15):
      	memory[address] = ac_reg;			//stor ac to memory
         break;
      default:
      	;
   }
   return;
}

void display()
{
	static int x;
   if (x == 0)
   {
   	cout << setw(10) << "REGISTERS:" << setw(13) << "    PC    ";
      cout << setw(10) << "    AC    " << setw(10) << "    IR    ";
      cout << setw(10) << "   MAR    " << setw(10) << "   MBR    ";
      cout << endl << endl;

      cout << setw(10) << "INITIAL:";
      cout << hex << setw(10) << pc_reg << setw(10) << ac_reg << setw(10) << ir_reg;
      cout << hex << setw(10) << ma_reg << setw(10) << mb_reg << endl << endl;
      x++;
   }
   else
   {
   	cout << setw(10) << "FINAL:";
   	cout << hex << setw(10) << pc_reg << setw(10) << ac_reg << setw(10) << ir_reg;
   	cout << hex << setw(10) << ma_reg << setw(10) << mb_reg << endl << endl;
   }
   return;
}

void request()
{
   short int num;
	cout << "enter locations to view using -1 as sentinel" << endl;
   cin >> num;
   while (num != -1)
   {
   	cout << hex << memory[num] << endl;
      cin >> num;
   }
   return;
}  
