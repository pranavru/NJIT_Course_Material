public class BinaryHex
{
	public static void main(String [] args)
	{
		String mask1 = "000000000000"; 
		String mask2 = "0000";		
		for (int i = 0; i < 256; i++)
		{
			String bin = Integer.toString(i, 2);
			String out1 = mask1.substring(0, mask1.length() - bin.length()) + bin; 
			String hex = Integer.toString(i, 16);
			String out2 = mask2.substring(0, mask2.length() - hex.length()) + hex;
			System.out.println(i + "\t" + out1 + "\t" + out2);
		}
	}
}