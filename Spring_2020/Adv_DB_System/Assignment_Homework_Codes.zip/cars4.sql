create table cars4 as (select * from geller.cars);

declare
    millions number;

begin
    for cu in (select * from cars)
    loop
        
        millions := trunc(cu.autos/1000000);
        -- dbms_output.put_line(millions);
        if(millions > 0) then 
            dbms_output.put_line(cu.state || ' ' || cu.autos);
        else 
            dbms_output.put_line(cu.state || ' ' || cu.autos);
        end if;    
        insert into cars4 values(cu.state, cu.autos, millions);
    end loop;
end;
/

select * from cars4;
/

truncate table cars4;

alter table cars4 add(millionsofcars number);
/


