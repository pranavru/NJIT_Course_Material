--Q1.A
create table test13(A int,B int,SUM int);

insert into test13 values (716,4,720);
insert into test13 values (919,40,959);
insert into test13 values (815,412,827);
insert into test13 values (1005,2000,3005);
insert into test13 values (837,456,1293);
insert into test13 values (724,20,744);

select * from test13;

select * from test13;

--Q1.B
/
create or replace trigger t4test13
before update on test13
for each row
begin
:new.sum := :new.A + :new.B;
end;
/
select * from test13;
/
update test13 set a = 400 where a = 716;
/
select * from test13;
/
update test13 set b = 30 where a = 724;
select * from test13;
/

--Q1.C
create or replace trigger t4test13B
before insert or update on test13
for each row
begin
:new.sum := :new.A + :new.B;
end;
/
insert into test13 (a, b) values (2, 5);
/
select * from test13;
/
insert into test13 values (18, 20, 2);
/
select * from test13;
/

--Q1.D
update test13 set A = A + 1;
/
select * from test13;
/

--Q1.E)
update test13 set A = A + 2 where A < 1000;
select * from test13;
/

select * from test13;
/

--Q2
declare
update test13 set A = A + 2 where A < 1000;
select * from test13;
/
cursor cur is select * from test13 for update;
begin
    for counter in cur
    loop
        if counter.A < 1000
        then
            dbms_output.put_line('Before updating value is - '||counter.A);
            update test13 set A = counter.A + 2 where current of cur;
            dbms_output.put_line('After updating value is - '||(counter.A + 2));
            dbms_output.put_line('-------------------------------');
        end if;
    end loop;
end;
/

select * from test13;
/

DROP TABLE TEST13;
/