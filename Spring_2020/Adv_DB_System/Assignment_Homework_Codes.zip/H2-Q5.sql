create table medical_abbr_disease_C (column1 varchar2(500), column2 varchar2(500));
/

select * from medical_abbr_disease_c;
/

DECLARE
    temp VARCHAR2(26);
    CURSOR myCursor is (SELECT * FROM medical_abbr_disease_c) FOR UPDATE;
    
--Q5.B    
BEGIN
    FOR val in myCursor
    LOOP
        IF val.column1 IS NULL
        THEN 
            UPDATE medical_abbr_disease_c SET column1 = temp WHERE CURRENT OF myCursor;
        ELSE
            temp := val.column1;
        END IF;
    END LOOP;
END;
/