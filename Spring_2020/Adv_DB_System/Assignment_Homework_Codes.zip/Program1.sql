CREATE TABLE wiki_med_abb2
( column1 varchar2(26 BYTE) NULL,
  column2 varchar2(1024 BYTE) NULL
);

declare
    value1 varchar2(80);
begin
    for colValue in (select * from wiki_med_abb)
    loop
        if colValue.column1 IS NULL 
        then
            INSERT INTO wiki_med_abb2 VALUES (value1, colValue.column2);
        else
            value1 := colValue.column1;
            INSERT INTO wiki_med_abb2 VALUES (colValue.column1, colValue.column2);
        end if;
    end loop;
end;
/

select * from wiki_med_abb;
/

select * from wiki_med_abb2;
/

DROP TABLE wiki_med_abb2;
/