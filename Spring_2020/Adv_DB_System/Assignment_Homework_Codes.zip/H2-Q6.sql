CREATE TYPE VIRUS AS OBJECT (
    NAME VARCHAR2(60),
    viralSize NUMBER,
    viralShape VARCHAR2(60),
    viralSymmetry VARCHAR2(60)
) NOT FINAL;
/

CREATE TABLE VIRUSES (virusObject VIRUS);
/

INSERT INTO VIRUSES VALUES (VIRUS('randomVirus1','17','rod','helical'));
/
INSERT INTO VIRUSES VALUES (VIRUS('randomVirus2','350','bullet','polyhedral'));
/
INSERT INTO VIRUSES VALUES (VIRUS('randomVirus3','200','brick','binal'));
/

select * from VIRUSES;
/

select * from medical_abbr_disease_c;

begin
    for v in (select * from VIRUSES)
    LOOP
        dbms_output.put_line(rpad('Name: ', 15)|| v.virusObject.Name);
        dbms_output.put_line(rpad('ViralSize: ', 15)|| v.virusObject.ViralSize);
        dbms_output.put_line(rpad('ViralShape: ', 15)|| v.virusObject.ViralShape);
        dbms_output.put_line(rpad('ViralSymmetry: ', 15)|| v.virusObject.ViralSymmetry);
    END LOOP;
END;
/

CREATE TYPE HostedVirus UNDER VIRUS (Hostrange VARCHAR2(60)) NOT FINAL;
/

CREATE TABLE VIRUSEStwo (VIRUS HostedVirus);
/

INSERT INTO VIRUSEStwo VALUES (HostedVirus ('randomVirus4','550','spherical','helical','bats'));
/
INSERT INTO VIRUSEStwo VALUES (HostedVirus ('randomVirus5','1040','rod','helical','human'));
/
SELECT * FROM VIRUSEStwo;
/

BEGIN
    FOR v2 IN (SELECT * FROM VIRUSEStwo)
    LOOP
        dbms_output.put_line(rpad('Name: ', 15)|| rpad(' --> ', 10)|| v2.VIRUS.Name);
        dbms_output.put_line(rpad('ViralSize: ', 15)|| rpad(' --> ', 10)|| v2.VIRUS.ViralSize);
        dbms_output.put_line(rpad('ViralShape: ', 15)|| rpad(' --> ', 10)|| v2.VIRUS.ViralShape);
        dbms_output.put_line(rpad('ViralSymmetry: ', 15)|| rpad(' --> ', 10)|| v2.VIRUS.ViralSymmetry);
        dbms_output.put_line(rpad('HostRange: ', 15)|| rpad(' --> ', 10)|| v2.VIRUS.Hostrange);
    END LOOP;
END;
/