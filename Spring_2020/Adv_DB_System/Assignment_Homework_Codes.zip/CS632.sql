Select * from geller.cs632spring2020

insert into geller.cs632spring2020 values('Pranav', 'Ruparelia', 'plr22')
