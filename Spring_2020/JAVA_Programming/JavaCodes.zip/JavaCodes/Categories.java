class Categories {
    String category;
    int taxvalue;

    Categories() {
        this.category = "tax";
        this.taxvalue = 0;
    }

    Categories( String c,  int t) {
        this.category = c;
        this.taxvalue = t;
    }
}