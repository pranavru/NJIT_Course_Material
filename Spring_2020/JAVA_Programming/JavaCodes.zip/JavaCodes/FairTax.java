import java.util.ArrayList;
import java.util.Scanner;

class FairTax {
    
    static Scanner sc = new Scanner(System.in);
    static ArrayList<Categories> categories = new ArrayList<Categories>();

    public static void inputCategories() {
        int n = 0;
        n = sc.nextInt();
        String[] cat = new String[2];
        sc.nextLine();
        for (int i = 1; i <= n; i++) {
            String value = sc.nextLine();
            cat = value.split(" ");
            Categories category = new Categories(cat[0], cat[1] != null? Integer.parseInt(cat[1]): 0);
            categories.add(category);
        }
    }

    public static void caculateTax() {
        System.out.print("The Total Sales Tax to be paid at the rate of 23% is: ");
        int sum = 0;
        for(Categories c: categories) {
            sum += c.taxvalue;
        }
        System.out.println(sum * 0.23);
        System.out.print("The Total Fair Tax to be paid at the rate of 30% is: ");
        System.out.println(sum * 0.3);

    }

    public static void displayTaxes() {
        for(Categories c: categories) {
            System.out.println("Category: " + c.category + " Tax Value is: " + c.taxvalue);
        }
    }

    public static void main(String args[]) {
        inputCategories();
        // displayTaxes();
        caculateTax();
    }
}

