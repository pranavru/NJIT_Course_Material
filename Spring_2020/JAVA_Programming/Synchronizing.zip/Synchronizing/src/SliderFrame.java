import java.awt.Color;
import java.awt.GridBagConstraints;
import java.awt.GridBagLayout;
import java.awt.event.KeyEvent;
import java.awt.event.KeyListener;

import javax.swing.JFrame;
import javax.swing.JSlider;
import javax.swing.JTextField;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.event.ChangeEvent;
import javax.swing.event.ChangeListener;

public class SliderFrame extends JFrame {

	private JSlider jSlider;
	private JTextField jTextField;
	private OvalPanel ovalPanel;

	public SliderFrame() {

		ovalPanel = new OvalPanel();
		ovalPanel.setBackground(Color.blue);

		jSlider = new JSlider();
		jSlider.setPaintTicks(true);
		jSlider.setMajorTickSpacing(10);
		jSlider.setValue(100);
		jSlider.addChangeListener(new ChangeListener() {

			@Override
			public void stateChanged(ChangeEvent e) {
				// TODO Auto-generated method stub
				ovalPanel.setDiameter(jSlider.getValue());
				jTextField.setText(jSlider.getValue() + "");
			}
		});

		jTextField = new JTextField();
		jTextField.setText("100");
		jTextField.addKeyListener(new KeyListener() {

			@Override
			public void keyTyped(KeyEvent e) {
			}

			@Override
			public void keyReleased(KeyEvent e) {
				jTextField.setEditable(true);

				try {
					if (Integer.parseInt(jTextField.getText()) > 100) {
						jTextField.setText("100");
					}
					int sliderValue = Integer.parseInt(jTextField.getText());
					jSlider.setValue(sliderValue);
				} catch (Exception exception) {
					jSlider.setValue(0);
				}
			}

			@Override
			public void keyPressed(KeyEvent e) {
				if ((e.getKeyChar() >= '0' && e.getKeyChar() <= '9') || e.getKeyCode() == 8 || e.getKeyCode() == 127
						|| e.getKeyCode() == 39 || e.getKeyCode() == 37) {
					jTextField.setEditable(true);
				} else {
					jTextField.setEditable(false);
				}
			}
		});

		JPanel panel = new JPanel();
		panel.add(new JLabel("Value: "));
		panel.add(jTextField);
		
		GridBagLayout gridBagLayout = new GridBagLayout();
		GridBagConstraints gridBagConstraints = new GridBagConstraints();
		setLayout(gridBagLayout);

		gridBagConstraints.fill = GridBagConstraints.BOTH;
		gridBagConstraints.gridwidth = 3;
		gridBagConstraints.gridheight = 3;
		gridBagConstraints.weighty = 1.0;
		gridBagConstraints.gridwidth = GridBagConstraints.REMAINDER;
		gridBagLayout.setConstraints(ovalPanel, gridBagConstraints);
		add(ovalPanel);

		gridBagConstraints.gridx = 0;
		gridBagConstraints.weightx = 1.0;
		gridBagConstraints.gridwidth = GridBagConstraints.RELATIVE;
		gridBagLayout.setConstraints(jSlider, gridBagConstraints);
		add(jSlider);

		gridBagConstraints.gridx = 1;
		gridBagConstraints.weightx = 1.0;
		gridBagConstraints.gridwidth = GridBagConstraints.REMAINDER;
		gridBagLayout.setConstraints(panel, gridBagConstraints);
		add(panel);

	}

}
