import java.awt.Color;
import java.awt.Dimension;
import java.awt.Graphics;
import javax.swing.JPanel;

public class OvalPanel extends JPanel {

	private int diameter = 100;
	@Override
	protected void paintComponent(Graphics g) {
		// TODO Auto-generated method stub
		super.paintComponent(g);
		int cntrOffset = diameter/2;
		int cntrX = (getWidth()/2) - diameter;
	    int cntrY = (getHeight()/2) - diameter;
	    g.setColor(Color.green);
		g.fillOval( cntrX, cntrY, diameter*2, diameter*2 );
	}
	
	public void setDiameter(int newDiameter) {
		diameter = ( newDiameter >= 0 ? newDiameter : 0 );
		repaint();
	}
	
	public Dimension getPreferredSize() {
		return new Dimension( 200, 200 );
	}
	
	public Dimension getMinimumSize()
	{
		return getPreferredSize();
	}
	
}
