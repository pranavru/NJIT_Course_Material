import javax.swing.JFrame;

public class SliderDemo {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		SliderFrame sliderFrame = new SliderFrame();
		sliderFrame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		sliderFrame.setSize(300,300);
		sliderFrame.setVisible(true);
	}

}
