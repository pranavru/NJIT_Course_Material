/* Pranav Ruparelia cs610 7952 prp */

import java.util.*;
import java.io.*;

class Pgrk_7952 {

    int iterations, initialValue = 0;
    String fileName = "";
    int noOfVertices, noOfEdges = 0;
    ArrayList<ArrayList<Integer>> L;
    final double d = 0.85;
    double errorrate = 0.00001;

    double[] Src;
    int[] OutgoingLinks; // array to contain number of outgoing links for page 'Ti'

    Pgrk_7952() {
    } // default constructor

    // Constructor with command line parameters
    Pgrk_7952(int iterations2, int initialvalue2, String file) throws FileNotFoundException {
        // Accept the arguments
        this.iterations = iterations2;
        this.initialValue = initialvalue2;
        this.fileName = file;

        Scanner sc = new Scanner(new File(this.fileName));
        noOfVertices = sc.nextInt();
        noOfEdges = sc.nextInt();

        // Initialize the Graph values to 0
        L = new ArrayList<ArrayList<Integer>>(noOfVertices);
        for (int i = 0; i < noOfVertices; i++) {
            ArrayList<Integer> addValues = new ArrayList<>();
            for (int j = 0; j < noOfVertices; j++) {
                addValues.add(0);
            }
            L.add(addValues);
        }

        // Set the graph
        while (sc.hasNextInt()) {
            ArrayList<Integer> addValues = L.get(sc.nextInt());
            addValues.set(sc.nextInt(), 1);
        }

        // Total number of Outgoing Links from a vertex
        OutgoingLinks = new int[noOfVertices];
        for (int i = 0; i < noOfVertices; i++) {
            OutgoingLinks[i] = 0;
            for (int j = 0; j < noOfVertices; j++) {
                ArrayList<Integer> addValues = L.get(i);
                OutgoingLinks[i] += addValues.get(j);
            }
        }

        // Base Values based on the initialValue parameter
        Src = new double[noOfVertices];
        switch (initialValue) {
            case 0:
                Src = baseSourceValues(0);
                break;
            case 1:
                Src = baseSourceValues(1);
                break;
            case -1:
                Src = baseSourceValues(1.0, noOfVertices);
                break;
            case -2:
                Src = baseSourceValues(1.0, Math.sqrt(noOfVertices));
                break;
        }
    }

    public static void main(String args[]) throws FileNotFoundException {
        if (args.length != 3) {
            System.out.println("Usage Pgrk_7952 (3 arguments): Pgrk_7952 iterations initialvalue filename");
            return;
        }
        // command line arguments
        int iterations = Integer.parseInt(args[0]);
        int initialvalue = Integer.parseInt(args[1]);
        String filename = args[2];

        if (!(initialvalue >= -2 && initialvalue <= 1)) {
            System.out.println("Usage Pgrk_7952: Enter -2, -1, 0 or 1 for initialvalue");
            return;
        }

        Pgrk_7952 pk = new Pgrk_7952(iterations, initialvalue, filename);

        pk.pgrkAlgo7952();
    }

    public double[] baseSourceValues(int value) {
        double[] a = new double[noOfVertices];
        for (int i = 0; i < noOfVertices; i++) {
            a[i] = value;
        }
        return a;
    }

    public double[] baseSourceValues(double value, double factor) {
        double[] a = new double[noOfVertices];
        for (int i = 0; i < noOfVertices; i++) {
            a[i] = (double) value / factor;
        }
        return a;
    }

    // Convergence to verify the values
    public boolean isConverged(double[] src, double[] target) {
        for (int i = 0; i < noOfVertices; i++) {
            if (Math.abs(src[i] - target[i]) > errorrate)
                return false;
        }
        return true;
    }

    // Page Rank algorithm
    public void pgrkAlgo7952() {
        double[] D = new double[noOfVertices];
        boolean flag = true;

        if (noOfVertices > 10) {
            // If vertices are greater than 10, then set iteration = 0 and initialValue to
            // -1.
            iterations = 0;
            Src = baseSourceValues(1.0, noOfVertices);

            // Perform iterations until values are same
            int i = 0;
            do {
                if (flag)
                    flag = false;
                else
                    Src = assignToSource(D);
                D = baseSourceValues(0);
                D = calculatePageRank();
                i++;
            } while (!isConverged(Src, D));

            printIterations(i, D);
            return;
        }

        // Printing the base case.
        printBaseCase();

        // When iterations are not equal to 0
        if (iterations != 0) {
            // If iterations are negative integers then errorrate changes to 10^ (-5 +
            // iterations)
            if (iterations < 0) {
                errorrate = Math.pow(10, -5 + iterations);
                int i = 0;
                do {
                    if (flag)
                        flag = false;
                    else
                        Src = assignToSource(D);
                    D = baseSourceValues(0);
                    D = calculatePageRank();
                    i++;
                    printIterations(i - 1, D);
                } while (!isConverged(Src, D));

                System.out.println();
            } else // If iterations are greater than 0
                for (int i = 0; i < iterations; i++) {
                    D = baseSourceValues(0);
                    D = calculatePR();
                    printIterations(i, D);
                    Src = assignToSource(D);
                }
        } else {
            int i = 0;
            do {
                if (flag)
                    flag = false;
                else
                    Src = assignToSource(D);
                D = baseSourceValues(0);
                D = calculatePageRank();
                i++;
                printIterations(i - 1, D);
            } while (!isConverged(Src, D));

            System.out.println();
        }
    }

    public double[] assignToSource(double[] D) {
        double a[] = new double[noOfVertices];
        for (int j = 0; j < noOfVertices; j++)
            a[j] = D[j];
        return a;
    }

    public double[] calculatePR() {
        double D[] = new double[noOfVertices];
        for (int j = 0; j < noOfVertices; j++) {
            for (int k = 0; k < noOfVertices; k++) {
                ArrayList<Integer> addValues = L.get(k);
                if (addValues.get(j) == 1) {
                    // System.out.printf("Src: " + Src[k] + "\tOutgoing Links: " + OutgoingLinks[k]
                    // + "\tD[" + k + "]: " + D[j] + "\n");
                    D[j] += (Src[k] / OutgoingLinks[k]);
                }
            }
        }
        return D;
    }

    public double[] calculatePageRank() {
        double D[] = calculatePR();
        for (int j = 0; j < noOfVertices; j++)
            D[j] = (d * D[j]) + ((1 - d) / noOfVertices);
        return D;
    }

    public void printBaseCase() {
        System.out.print("Base:    0 :");
        for (int i = 0; i < noOfVertices; i++) {
            System.out.printf(" :P[" + i + "]=%.7f", Math.round(Src[i] * 1000000.0) / 1000000.0);
        }
        System.out.println();
    }

    public void printIterations(int iteration, double D[]) {
        System.out.println();
        System.out.print("Iter:    " + (iteration + 1) + " :\n");
        for (int i = 0; i < noOfVertices; i++) {
            D[i] = (d * D[i]) + ((1 - d) / noOfVertices);
            System.out.printf((noOfVertices > 10) ? " :P[" + i + "]=%.7f\n" : " :P[" + i + "]=%.7f",
                    Math.round(D[i] * 1000000.0) / 1000000.0);
        }
        System.out.println();
    }
}