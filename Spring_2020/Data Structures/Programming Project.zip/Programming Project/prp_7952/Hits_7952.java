/* Pranav Ruparelia cs610 7952 prp */

import java.util.*;
import java.io.*;

class Hits_7952 {

    // Initialization
    int iterations = 0, initialValue = 0;
    String fileName = "";
    int noOfVertices, noOfEdges = 0;
    double[] h0, a0;
    ArrayList<ArrayList<Integer>> L;
    double errorrate = 0.00001;

    Hits_7952() {
    }

    // Constructor
    Hits_7952(int iterations2, int initialvalue2, String file) throws FileNotFoundException {

        this.iterations = iterations2;
        this.initialValue = initialvalue2;
        this.fileName = file;

        Scanner sc = new Scanner(new File(this.fileName));
        noOfVertices = sc.nextInt();
        noOfEdges = sc.nextInt();

        h0 = new double[noOfVertices];
        a0 = new double[noOfVertices];
        L = new ArrayList<ArrayList<Integer>>(noOfVertices);

        for (int i = 0; i < noOfVertices; i++) {
            ArrayList<Integer> addValues = new ArrayList<>();
            for (int j = 0; j < noOfVertices; j++) {
                addValues.add(0);
            }
            L.add(addValues);
        }

        while (sc.hasNextInt()) {
            ArrayList<Integer> addValues = L.get(sc.nextInt());
            addValues.set(sc.nextInt(), 1);
        }

        // Set h0 and a0
        switch (initialValue) {
            case 0:
                initializeAuthHubs(0);
                break;
            case 1:
                initializeAuthHubs(1);
                break;
            case -1:
                initializeAuthHubs(1.0, noOfVertices);
                break;
            case -2:
                initializeAuthHubs(1.0, Math.sqrt(noOfVertices));
                break;
        }

    }

    public static void main(String args[]) throws FileNotFoundException {
        if (args.length != 3) {
            System.out.println("Usage Hits_7952 (3 arguments): Hits_7952 iterations initialvalue filename");
            return;
        }
        // command line arguments
        int iterations = Integer.parseInt(args[0]);
        int initialvalue = Integer.parseInt(args[1]);
        String filename = args[2];

        if (!(initialvalue >= -2 && initialvalue <= 1)) {
            System.out.println("Usage Hits_7952: Enter -2, -1, 0 or 1 for initialvalue");
            return;
        }

        Hits_7952 ht = new Hits_7952(iterations, initialvalue, filename);

        ht.hitsAlgo7952();
    }

    public void initializeAuthHubs(int v) {
        for (int i = 0; i < noOfVertices; i++) {
            h0[i] = v;
            a0[i] = v;
        }
    }

    public void initializeAuthHubs(double v, double factor) {
        for (int i = 0; i < noOfVertices; i++) {
            h0[i] = v / factor;
            a0[i] = v / factor;
        }
    }

    public void hitsAlgo7952() {
        double[] h = new double[noOfVertices];
        double[] a = new double[noOfVertices];
        double[] aprev = new double[noOfVertices];
        double[] hprev = new double[noOfVertices];

        if (noOfVertices > 10) {
            iterations = 0;
            for (int i = 0; i < noOfVertices; i++) {
                h[i] = 1.0 / noOfVertices;
                a[i] = 1.0 / noOfVertices;
                hprev[i] = h[i];
                aprev[i] = a[i];
            }

            int i = 0;
            do {
                for (int r = 0; r < noOfVertices; r++) {
                    aprev[r] = a[r];
                    hprev[r] = h[r];
                }

                a = resetAuthHub(noOfVertices);

                for (int j = 0; j < noOfVertices; j++) {
                    for (int k = 0; k < noOfVertices; k++) {
                        ArrayList<Integer> ww = L.get(k);
                        if (ww.get(j) == 1)
                            a[j] += h[k];
                    }
                }

                h = resetAuthHub(noOfVertices);

                for (int j = 0; j < noOfVertices; j++) {
                    ArrayList<Integer> addValues = L.get(j);
                    for (int k = 0; k < noOfVertices; k++) {
                        if (addValues.get(k) == 1) {
                            h[j] += a[k];
                        }
                    }
                }

                // Scaling starts
                a = scalingHubsAuthsSC(a, noOfVertices, scaleFactor(a, noOfVertices));
                h = scalingHubsAuthsSC(h, noOfVertices, scaleFactor(h, noOfVertices));

                i++;

            } while (false == isConverged(a, aprev) || false == isConverged(h, hprev));
            printIterations(i, a, h);
            return;
        }

        // Initialization of Base and previous authorities and hubs
        for (int i = 0; i < noOfVertices; i++) {
            h[i] = h0[i];
            a[i] = a0[i];
            hprev[i] = h[i];
            aprev[i] = a[i];
        }

        // Base Case
        printBaseCase();

        if (iterations != 0) {
            if (iterations < 0) {
                errorrate = Math.pow(10, (-5 + iterations));
                int i = 0;
                do {
                    for (int r = 0; r < noOfVertices; r++) {
                        aprev[r] = a[r];
                        hprev[r] = h[r];
                    }

                    // A step starts
                    a = resetAuthHub(noOfVertices);

                    for (int j = 0; j < noOfVertices; j++) {
                        for (int k = 0; k < noOfVertices; k++) {
                            ArrayList<Integer> ww = L.get(k);
                            if (ww.get(j) == 1)
                                a[j] += h[k];
                        }
                    }

                    h = resetAuthHub(noOfVertices);

                    for (int j = 0; j < noOfVertices; j++) {
                        ArrayList<Integer> addValues = L.get(j);
                        for (int k = 0; k < noOfVertices; k++) {
                            if (addValues.get(k) == 1) {
                                h[j] += a[k];
                            }
                        }
                    }

                    a = scalingHubsAuthsSC(a, noOfVertices, scaleFactor(a, noOfVertices));
                    h = scalingHubsAuthsSC(h, noOfVertices, scaleFactor(h, noOfVertices));

                    i++;

                } while (false == isConverged(a, aprev) || false == isConverged(h, hprev));
                printIterations(i, a, h);
                return;
            }
            for (int i = 0; i < iterations; i++) {

                a = resetAuthHub(noOfVertices);

                for (int j = 0; j < noOfVertices; j++) {
                    for (int k = 0; k < noOfVertices; k++) {
                        ArrayList<Integer> ww = L.get(k);
                        if (ww.get(j) == 1)
                            a[j] += h[k];
                    }
                }

                h = resetAuthHub(noOfVertices);

                for (int j = 0; j < noOfVertices; j++) {
                    ArrayList<Integer> addValues = L.get(j);
                    for (int k = 0; k < noOfVertices; k++) {
                        if (addValues.get(k) == 1) {
                            h[j] += a[k];
                        }
                    }
                }

                a = scalingHubsAuthsSC(a, noOfVertices, scaleFactor(a, noOfVertices));
                h = scalingHubsAuthsSC(h, noOfVertices, scaleFactor(h, noOfVertices));

                printIterations(i, a, h);
                System.out.println();
            }
        } else if (iterations == 0) {
            int i = 0;
            do {
                for (int r = 0; r < noOfVertices; r++) {
                    aprev[r] = a[r];
                    hprev[r] = h[r];
                }

                // A step starts
                a = resetAuthHub(noOfVertices);

                for (int j = 0; j < noOfVertices; j++) {
                    for (int k = 0; k < noOfVertices; k++) {
                        ArrayList<Integer> ww = L.get(k);
                        if (ww.get(j) == 1)
                            a[j] += h[k];
                    }
                }

                h = resetAuthHub(noOfVertices);

                for (int j = 0; j < noOfVertices; j++) {
                    ArrayList<Integer> addValues = L.get(j);
                    for (int k = 0; k < noOfVertices; k++) {
                        if (addValues.get(k) == 1) {
                            h[j] += a[k];
                        }
                    }
                }

                a = scalingHubsAuthsSC(a, noOfVertices, scaleFactor(a, noOfVertices));
                h = scalingHubsAuthsSC(h, noOfVertices, scaleFactor(h, noOfVertices));

                i++;

                printIterations(i, a, h);
            } while (false == isConverged(a, aprev) || false == isConverged(h, hprev));
        }
        System.out.println();
    }

    public boolean isConverged(double[] p, double[] q) {
        for (int i = 0; i < noOfVertices; i++) {
            if (Math.abs(p[i] - q[i]) > errorrate)
                return false;
        }
        return true;
    }

    public void printBaseCase() {
        System.out.print("Base:    0 :");
        for (int i = 0; i < noOfVertices; i++) {
            System.out.printf(" A/H[%d]=%.7f/%.7f", i, Math.round(a0[i] * 1000000.0) / 1000000.0,
                    Math.round(h0[i] * 1000000.0) / 1000000.0);
        }
        System.out.println();
    }

    public double scaleFactor(double a[], int noOfVertices) {
        double a_sumOfSquares = 0.0;
        for (int j = 0; j < noOfVertices; j++) {
            a_sumOfSquares += a[j] * a[j];
        }
        return Math.sqrt(a_sumOfSquares);
    }

    public double[] resetAuthHub(int noOfVertices) {
        double a[] = new double[noOfVertices];
        for (int j = 0; j < noOfVertices; j++)
            a[j] = 0.0;
        return a;
    }

    public double[] scalingHubsAuthsSC(double a[], int noOfVertices, double scaleFactor) {
        for (int j = 0; j < noOfVertices; j++) {
            a[j] = a[j] / scaleFactor;
        }
        return a;
    }

    public void printIterations(int iteration, double a[], double h[]) {
        System.out.println();
        System.out.print("Iter:    " + (iteration + 1) + " :\n");
        for (int l = 0; l < noOfVertices; l++) {
            System.out.printf((noOfVertices > 10) ? " A/H[%d]=%.7f/%.7f\n" : " A/H[%d]=%.7f/%.7f", l,
                    Math.round(a[l] * 1000000.0) / 1000000.0, Math.round(h[l] * 1000000.0) / 1000000.0);
        }
    }
}